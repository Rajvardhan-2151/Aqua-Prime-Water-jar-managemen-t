package study.Constrollers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import study.Dao.CustomerDao;
import study.entity.Customer;
import study.entity.CustomerBill;
import study.extraLogic.Validation;

@Controller
public class CustomerController {

	@Autowired
	CustomerDao customer_dao;
	
	@Autowired
	Validation val_obj;
	
	
	@GetMapping("/checkLogin")
	public String checkCustomer( Model model , @RequestParam String username , @RequestParam String password)
	{
	    Customer customer = val_obj.validateCustomer(username, password);
	   
	    if(customer!=null)
	    {
	       model.addAttribute("customer", customer);
	       return "/CustomerViews/AfterCustomerLogin";
		}
	    else	
		return "/CustomerViews/CustomerLogin";
	}
	
	
	@GetMapping("/getCustomerData")
	public void getdata(@RequestParam int id)
	{
		customer_dao.getCustomerData(id);
	}
	
	
	@GetMapping("/addCustomer")
	public String addCustomer(@RequestParam String Fname, @RequestParam String Lname, @RequestParam String Address,@RequestParam String MobileNo, @RequestParam String Email, @RequestParam String Username, @RequestParam String Password,@RequestParam int Pincode, @RequestParam String DeliveryAddress)
	{
		Customer cust = new Customer(Fname , Lname ,Address, MobileNo, Email, Username, Password, Pincode, DeliveryAddress);
		customer_dao.addCustomer(cust);
		return "/CustomerViews/CustomerLogin";
	}
	
	
	
	@GetMapping("/ViewBill")
	public String ViewBill(Model model, @RequestParam int customer_id)
	{
		CustomerBill bill = customer_dao.viewBill(customer_id);
		//System.out.println(bill.getCustomerBillForMonth()+"  "+bill.getCustomerBillStatus()+"  "+bill.getTotalAmountRs()+"  "+bill.getTotalOrderDays());
		model.addAttribute("billOfCustomer", bill);
		return "/CustomerViews/ViewCustomerBill";
		
	}
	
	
	
	
	
	
	
	
}
