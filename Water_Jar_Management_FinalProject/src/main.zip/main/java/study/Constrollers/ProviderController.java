package study.Constrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import study.Dao.CategoryDao;
import study.Dao.ExtraOrderDao;
import study.Dao.SupplierDao;
import study.entity.JarCategory;
import study.entity.Supplier;

@RestController
public class ProviderController {
	
	@Autowired
	SupplierDao sup_dao;
	
	
	@GetMapping("/AddSupplier")
	public void addSupplier(String firstName , String lname , String address , String mobile_no , String email , String username , String password , String working_area , int pincode)
	{
		Supplier sup_obj = new Supplier(firstName , lname , address , mobile_no, email, username, password, working_area, pincode);
		sup_dao.AddSuplier(sup_obj);
	}
	
	
	@GetMapping("/getSupplierList")
	public void SupplierList()
	{
		sup_dao.getAllSupplier();
	}
	
	
	
	@GetMapping(name="ViewCount")
	public void ViewCount()
	{
		
	}
	
}
