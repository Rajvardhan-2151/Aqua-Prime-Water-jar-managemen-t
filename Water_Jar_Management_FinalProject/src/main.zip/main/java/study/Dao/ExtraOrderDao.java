package study.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import study.Repository.ExtraOrderRepository;
import study.entity.ExtraOrder;

@Service
public class ExtraOrderDao {

	@Autowired
	private ExtraOrderRepository extraOrder_repo;
	
	
	public void extraOrderCount()
	{
		List<ExtraOrder> orders =  extraOrder_repo.getOrderForProviderCount();
		for(ExtraOrder ord : orders)
		{
			System.out.println(ord.getOrderDeliveryDate()+"  "+ord.getJarQauntity()+"  "+ord.getJarCategoryTable().getJarCapacity());
		}
	}
	
	
	
	public void getOrdersforSupplier(int id)
	{
	  List<ExtraOrder> order = extraOrder_repo.getExtraOrderSupplier(id);
	  for(ExtraOrder ord : order)
	  {
		  System.out.println(ord.getOrderDate()+"  "+ord.getCustomerInfoTable().getCustomerFname()+"  "+ord.getCustomerInfoTable().getCustomerLname()+"  "+ord.getCustomerInfoTable().getCustomerDeliveryAddress());
			
			 String d2 = ord.getCustomerInfoTable().getCustomerDeliveryAddress();
	  }
		
		/*List<Subscription> list =  sub_dao.findBysupplier_id(id);
	  
	   for(Subscription sub : list)
	   {
		   System.out.println(sub.getCustomerInfoTable().getCustomerFname());
	   }
		
		List<NonDelivery> ndlist = nd_dao.getNonDeliveryDate();
		for(NonDelivery nd : ndlist)
		{
			System.out.println(nd.getNonDeliveryDate());
		}*/
	  
	  
		/*
		 * List<Subscription> list = subscription_dao.subscriptedOrder();
		 * //sub_repo.GetSubscriptedOrders(); for(Subscription sub : list) {
		 * System.out.println(sub.getCustomerInfoTable().getCustomerFname()+"  "+sub.
		 * getCustomerInfoTable().getCustomerDeliveryAddress()); }
		 */
	}
	
	
}
