package study.Constrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import study.Dao.CategoryDao;
import study.entity.JarCategory;

public class CategoryController {

	@Autowired
	CategoryDao jarCate_dao;
	
	
	@GetMapping("/viewProducts")
	public void ViewProducts()
	{
		jarCate_dao.getAllProduct();
	}
	
	
	
	@GetMapping("/AddProduct")
	public void addProduct(String jar_capacity , String water_type , int price)
	{
		jarCate_dao.addProduct(new JarCategory(jar_capacity , water_type, price));
	}
}
