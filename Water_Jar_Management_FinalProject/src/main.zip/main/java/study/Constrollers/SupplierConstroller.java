package study.Constrollers;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import study.Dao.BillingDao;
import study.Dao.CategoryDao;
import study.Dao.CustomerDao;
import study.Dao.ExtraOrderDao;
import study.Dao.NondeliveryDao;
import study.Dao.SubscriptionDao;
import study.Dao.SupplierDao;
import study.Repository.CustomerRepository;
import study.Repository.ExtraOrderRepository;
import study.Repository.NonDeliveryRepository;
import study.Repository.SubscriptionRepository;
import study.Repository.SupplierRepository;
import study.entity.Customer;
import study.entity.ExtraOrder;
import study.entity.JarCategory;
import study.entity.NonDelivery;
import study.entity.Subscription;
import study.entity.Supplier;
import study.extraLogic.BillGeneration;
import study.extraLogic.Validation;
import study.extraLogic.BillGeneration;

@Controller
public class SupplierConstroller {

	@Autowired
	Validation val_obj;
	
	@Autowired
	SubscriptionDao subscription_dao;
	
	@Autowired
	BillingDao bill_dao;
	
    @Autowired
	BillGeneration genarateBill;
	
	@Autowired
	BillingDao bill;
	
	@Autowired
	CustomerDao cust_dao;
	
	

	@GetMapping("/checkSupplierLogin")
	public String checkSupplier( Model model , @RequestParam String username , @RequestParam String password)
	{
	    Supplier supplier = val_obj.validateSupplier(username, password);
	   
	    if(supplier!=null)
	    {
	       model.addAttribute("supplier", supplier);
	       return "/SupplierViews/AfterSupplierLogin";
		}
	    else	
		return "/SupplierViews/SupplierLogin";
	}
	
	
	
	@GetMapping("/addSupplier")
	public String addSupplier(@RequestParam int id)
	{
		return "/SupplierViews/SupplierLogin";
	}
	
	
	
	@PostMapping("/GenerateBill")
	public String GenerateBill(String start_Date , String end_Date , int cust_id)
	{
        List<Subscription> list = subscription_dao.validSubscription(cust_id);
		
        int TotalNoDays = 0;
		if(list.isEmpty())
		{//Non Subscripted
			bill_dao.GenerateBillFromExtraOrder(start_Date, end_Date, cust_id);  //Extra Order Find Krnyasathi
		}
		else
		{   //subscripted
			int customer_id = 0;
			for(Subscription sub : list)
			{
			  customer_id = sub.getCustomerInfoTable().getCustomerId();
	          TotalNoDays = TotalNoDays+genarateBill.findBill(sub);
			}
			bill.addCustomerBill(customer_id, TotalNoDays , (TotalNoDays*10) , (TotalNoDays*150));
		}
		
		return "/SupplierViews/AfterSupplierLogin";
	}
	
	
	
	
	@GetMapping("GenerateBill")
	public String GenerateBill(Model model , @RequestParam int cust_id)
	{
		Customer customer =  cust_dao.getSingleCustomer(cust_id);
		model.addAttribute("customer", customer);
		return "/SupplierViews/GenerateBill";
	}
	
}




