package study.Constrollers;


import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import study.Dao.BillingDao;
import study.Dao.CategoryDao;
import study.Dao.CustomerDao;
import study.Dao.NondeliveryDao;
import study.Dao.SubscriptionDao;
import study.Dao.SupplierDao;
import study.Repository.CustomerRepository;
import study.entity.Customer;
import study.entity.JarCategory;
import study.entity.Subscription;
import study.entity.Supplier;
import study.extraLogic.BillGeneration;

@RestController
public class SubscriptionController {

	@Autowired
	SubscriptionDao subscription_dao;
	
	@Autowired
	BillingDao bill_dao;
	
	@Autowired
	CustomerDao cust_dao;
	
	@Autowired
	SupplierDao sup_dao;
	
	@Autowired
	CategoryDao cat_dao;
	
	@Autowired
	BillGeneration genarateBill;
	
	@Autowired
	NondeliveryDao non_del_dao;
	
	@Autowired
	BillingDao bill;
	
	
	@GetMapping("/AddSubscription")
	public void addSubscription(int customer, int jarCategory, int supplier, String subscriptionStartDate,String subscriptionEndDate, String subscriptionStatus)
	{
		//CustomerDao cust_dao = new CustomerDao();
		Customer newCustomer = cust_dao.getSingleCustomer(customer );
		
		//SuppierDao sup_dao = new SuppierDao();
		Supplier newSupplier =  sup_dao.getSingleSupplier(supplier);
		
		//CategoryDao cat_dao = new CategoryDao();
		JarCategory category = cat_dao.getSingJarInfo(jarCategory);
		
		Date start_date = new Date(2022-03-22);
		Date end_date = new Date(2022-04-22);
		
		Subscription newSubscription = new Subscription(newCustomer , category , newSupplier , start_date , end_date , "Active" );
		subscription_dao.addSubscription(newSubscription);
	}
	
	
	
	


}
