package study.Constrollers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillingController {

	
	
}
