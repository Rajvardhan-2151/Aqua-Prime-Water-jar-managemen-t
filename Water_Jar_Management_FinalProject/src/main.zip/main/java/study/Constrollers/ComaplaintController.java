package study.Constrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


import study.Dao.ComplaintDao;
import study.Repository.ComplaintRepository;
import study.entity.ComplaintTable;

@Controller
public class ComaplaintController {

	@Autowired
	ComplaintDao complaint_dao;
	
	@Autowired
	private ComplaintRepository comapliant_repo;
	
	//http://localhost:8080/addComplaint?customer_id=3&info=%22jmly%20ata%22&status=%22active%22
	@GetMapping("/addComplaint")
	public String addComaplaint(Model model , @RequestParam int customer_id ,@RequestParam String info , @RequestParam String status)
	{
		System.out.println("Inside it");
		ComplaintTable complaints = null;
		boolean returnStatus = complaint_dao.addComplaint(customer_id, info, status);
		if(returnStatus)
		{
			complaints =  complaint_dao.getCompalint(customer_id);
		}
		model.addAttribute("comp", complaints);
		
		return "/CustomerViews/viewComplaint";
	}
	
	
	@GetMapping("/resolveComapliant")
	public void resolveCompliant()
	{
		
	}
	
	
	@GetMapping("/redirectComapliant")
	public String redirectComaplintPage( Model model, @RequestParam int customer_id)
	{
		model.addAttribute("customer_id", customer_id);
		return "/CustomerViews/AddComplaint";
	}
}
